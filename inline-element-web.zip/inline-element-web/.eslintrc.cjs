module.exports = {
  "extends": [
    "./.eslintrc-auto-import.json"
],
}