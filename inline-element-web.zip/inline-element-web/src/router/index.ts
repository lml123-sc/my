// src/router/index.ts
import { createRouter, createWebHashHistory, type RouteRecordRaw } from 'vue-router';

// 静态路由
export const constantRoutes: Array<RouteRecordRaw> = [
  {
    path: '/home',
    component: () => import('@/views/home/index.vue'),
    meta: { hidden: true }
  },
  { path: '/:pathMatch(.*)*', redirect: '/home' },
];

/**
 * 创建路由
 */
const router = createRouter({
  history: createWebHashHistory(),
  routes: constantRoutes,
  // 刷新时，滚动条位置还原
  scrollBehavior: () => ({ left: 0, top: 0 })
});

/**
 * 重置路由
 */
export function resetRouter() {
  router.replace({ path: '/home' });
  location.reload();
}

export default router;
