// src/store/modules/user/index.ts

import { defineStore } from 'pinia';

export const useUserStore = defineStore('user', {
  // id: 'user', // id必填，且需要唯一。两种写法
  state: () => {
    return {
      userInfo: {}
    };
  },
  actions: {
    updateUser(userInfo: any) {
      this.userInfo = userInfo;
    },
  },
});
