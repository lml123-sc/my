<template>
  <div>123</div>
</template>
<script setup lang="ts">
import { useUserStore } from '@/store/module/user';

console.log(useUserStore().userInfo)
</script>